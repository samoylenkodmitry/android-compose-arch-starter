plugins { alias(libs.plugins.kotlin) }

dependencies {
  // pure Kotlin
}
