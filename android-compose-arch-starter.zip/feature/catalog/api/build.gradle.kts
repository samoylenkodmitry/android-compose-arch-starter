plugins { alias(libs.plugins.kotlin) }

dependencies {
  implementation(project(":core:common"))
}
